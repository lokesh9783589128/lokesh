# Pokedex

:pencil2: Made for practice

- [Live](https://js-pokedex-virid.vercel.app/)
- [Design by AC1design](https://dribbble.com/shots/15128634-Pokemon-Pokedex-Website-Redesign-Concept)
- [PokeAPI](https://pokeapi.co/)
