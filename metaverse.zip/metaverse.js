{/* <script>

       function img(){
            alert("soon")
        }
        function button(){
            alert("soon!")
        }

        burger = document.querySelector('.burger')
navlist = document.querySelector('.nav-list')
navlistli= document.querySelector('.nav-list li')

burger.addEventListener('click',()=>{
    navlistli.classList.toggle('h-list');
    navlist.classList.toggle('h-list');
})
  </script> */}